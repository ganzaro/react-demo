const nodes = [
    {
        id: 1,
        name: "node 1",
        price: 1,
        transactions: 50
    },

    {
        id: 2,
        name: "node 2",
        price: 1,
        transactions: 10
    },

    {
        id: 3,
        name: "node 3",
        price: 1,
        transactions: 18
    },
]

export default nodes
